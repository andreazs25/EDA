import java.util.Map.Entry;

public class Actor implements Comparable<Actor> {
	private String nombre;
	private LisPeli listaP;
	private Double centralidad=0.0;

	public Actor(String o) {
		this.nombre = o;
		listaP = new LisPeli();
		this.centralidad=0.0;
	}
	public double getCentralidad() {
		return centralidad;
	}
	public void setCentralidad(Double centralidad) {
		this.centralidad = centralidad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public LisPeli getListaP() {
		return listaP;
	}

	public void setListaP(LisPeli listaP) {
		this.listaP = listaP;
	}

	@Override
	public int compareTo(Actor A) {
		// TODO Auto-generated method stub

		return this.nombre.compareTo(A.nombre);
	}

	public void devolverListaDeActor() {

		for (Entry<String, Peli> unaPeli : this.listaP.getLp().entrySet()) {
			String clave = unaPeli.getKey();
			System.out.println(clave);

		}

	}
}
