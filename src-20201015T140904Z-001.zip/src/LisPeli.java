

import java.util.HashMap;

public class LisPeli {

    private HashMap<String, Peli> lp;

    public LisPeli() {
        this.lp = new HashMap<String, Peli>();
    }

   
    public void anadir(String pTitulo) {
    	if(!this.lp.containsKey(pTitulo))
        this.lp.put(pTitulo, new Peli(pTitulo));
    }

    public Peli Devolver(String p) {
        return this.lp.get(p);
    }

    public int longitud() {
        return this.lp.size();
    }

    public HashMap<String, Peli> getLp() {
        return lp;
    }

    public void setLp(HashMap<String, Peli> lp) {
        this.lp = lp;
    }

    public void eliminarPeli(String titulo) {
        this.lp.remove(titulo);
    }

}
