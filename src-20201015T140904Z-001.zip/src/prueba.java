import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Map.Entry;

public class prueba {

	public static void main(String[] args) throws IOException {
		
		// TODO Auto-generated method stub
		Gestor.getGestor().CargarDatosFichero();
		Graph2 a=new Graph2();
		a.crearGrafo();
		long star_time = System.currentTimeMillis();
		System.out.println(a.gradoRelaciones());
		ArrayList<Actor> actor= a.losDeMasCentralidad(10);
		for (Actor ac: actor) {
			System.out.println(ac.getNombre() + " Centralidad: "+ac.getCentralidad());
		}
		long end_time = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n es:"+ (end_time-star_time));
		/**
		System.out.println(" ");
		boolean estan=a.estanConectados("Talvy, Joe", "Kennedy, Jamie (I)");
		System.out.println(estan);
		System.out.println(" ");
		estan=a.estanConectados("Huntington, Alaine", "Erenberger, Amy");
		System.out.println(estan);
		System.out.println(" ");
		estan=a.estanConectados("Talvy, Joe", "Talvy, Joe");
		System.out.println(estan);
		System.out.println(" ");
		
		
		ArrayList<String> camino= new ArrayList<String>();
		camino =a.estanConectados2("Talvy, Joe", "Kennedy, Jamie (I)"); 
		a.imprimirCamino(camino);  //Estan conectados y el camino es String[]
		System.out.println(" ");
		camino=a.estanConectados2("Huntington, Alaine", "Erenberger, Amy");
		a.imprimirCamino(camino);  //No estan conectados 
		System.out.println(" ");
		camino=a.estanConectados2("Talvy, Joe", "Talvy, Joe");
		a.imprimirCamino(camino); //Esta conectado consigo mismo y el camino es "Talvy, Joe"
		
		**/
		
		
		
}	


}	
	
	
	
	
		

