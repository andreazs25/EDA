import java.util.Map.Entry;

public class Peli {
	private String titulo;
	private LisActores la;
	private double recaudacion;

	public Peli(String o) {
		this.titulo = o;
		this.la = new LisActores();
		this.recaudacion = 0.0;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public LisActores getLa() {
		return la;
	}

	public void setLa(LisActores la) {
		this.la = la;
	}

	public double getRecaudacion() {
		return recaudacion;
	}

	public void setRecaudacion(double recaudacion) {
		this.recaudacion = recaudacion;

	}

	public void incrementarReca(double valor) {
		this.recaudacion = this.recaudacion + valor;

	}

	public void devolverListaDePeli() {

		for (Entry<String, Actor> unActor : this.getLa().getLista().entrySet()) {
			String clave = unActor.getKey();
			System.out.println(clave);

		}

	}
}
