import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Map.Entry;

public class Gestor {

	// atributos
	LisPeli CatalogoP;
	LisActores CatalogoA;
	// String []listaOrdenada;

	private static Gestor miGestor;

	// constructora
	private Gestor() {
		this.CatalogoP = new LisPeli();
		this.CatalogoA = new LisActores();

	}

	// getters y setters
	public static Gestor getGestor() {
		if (miGestor == null) {
			miGestor = new Gestor();
		}
		return miGestor;
	}

	public LisPeli getListaP() {
		return this.CatalogoP;
	}

	public LisActores getListaA() {
		return this.CatalogoA;
	}

	public void CargarDatosFichero() throws IOException {
		Stopwatch timer = new Stopwatch();
		String cadena;
		Scanner entrada = new Scanner(new FileReader(
				"fichero/actors-movies-2015-2016.txt"));
		while (entrada.hasNext()) {
			cadena = entrada.nextLine();
			String f[] = cadena.split(" ### ");
			String Act = f[0];

			CatalogoA.anadir(Act);
			for (int i = 1; i < f.length; i++) {
				this.CatalogoP.anadir(f[i]);
				CatalogoA.buscarActor(Act).getListaP().anadir(f[i]);

			}
		}
		this.cargarActoresPorPeli();
		entrada.close();
		System.out.println(timer.elapsedTime());
	}

	public void cargarActoresPorPeli() throws IOException {
		for (Entry<String, Actor> unActor : CatalogoA.getLista().entrySet()) {
			LisPeli listaP = unActor.getValue().getListaP();
			for (Entry<String, Peli> unPeli : listaP.getLp().entrySet()) {
				CatalogoP.getLp().get(unPeli.getKey()).getLa()
						.anadir(unActor.getKey());
			}

		}

	}

	public void guardarFichero() throws IOException {
		Gestor.getGestor().CargarDatosFichero();
		String[] ListaO = Gestor.getGestor().getListaA().ordenarActores();
		try {

			PrintWriter pw = new PrintWriter("src/fichero/listag.txt");

			for (int j = 0; j < ListaO.length; j++) {
				String unActor = ListaO[j];
				LisPeli lp = Gestor.getGestor().getListaA()
						.buscarActor(unActor).getListaP();
				pw.println(unActor);
				for (Entry<String, Peli> unaPeli : lp.getLp().entrySet()) {
					String clave = unaPeli.getKey();
					pw.println("\t\t\t" + clave);

				}
			}

			pw.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}

	}

}
