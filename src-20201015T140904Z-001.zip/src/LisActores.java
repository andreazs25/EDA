
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeMap;

public class LisActores {

	HashMap<String, Actor> La = new HashMap<String, Actor>();

	public void anadir(String pNombre) {
		if (!this.La.containsKey(pNombre))
			this.La.put(pNombre, new Actor(pNombre));
	}

	public int longitud() {
		return this.La.size();
	}

	public Actor buscarActor(String A)

	{
		Actor unActor = null;
		if (!this.La.isEmpty()) {
			

				unActor = this.La.get(A);
			}
		return unActor;
		}
	
	

	public HashMap<String, Actor> getLista() {
		return this.La;
	}

	private String[] copiarNombres() {
		String[] nombreActores = new String[La.size()];
		// como recorro el gestor
		int i = 0;
		for (Entry<String, Actor> unActor : La.entrySet()) {
			String clave = unActor.getKey();
			nombreActores[i] = clave;
			i++;
		}
		return nombreActores;
	}

	public String[] ordenarActores() {
		String[] actores = this.copiarNombres();
		ordenarActores(actores, 0, actores.length - 1);
		return actores;
	}

	private void ordenarActores(String[] actores, int inicio, int fin) {
		if (inicio < fin) {
			ordenarActores(actores, inicio, ((inicio + fin) / 2));
			ordenarActores(actores, ((inicio + fin) / 2) + 1, fin);
			Mezcla(actores, inicio, ((inicio + fin) / 2), fin);
		}

	}

	private void Mezcla(String[] actores, int inicio, int centro, int fin) {
		String[] laMezcla = new String[fin - inicio + 1];

		int izq = inicio;
		int der = centro + 1;
		int k = 0;
		while (izq <= centro && der <= fin) {
			if (actores[izq].compareTo(actores[der]) <= 0) {
				laMezcla[k] = actores[izq];
				k++;
				izq++;
			} else {

				laMezcla[k] = actores[der];
				k++;
				der++;
			}
		}
		if (izq > centro) {
			while (der <= fin) {
				laMezcla[k] = actores[der];
				k++;
				der++;
			}
		} else {
			while (izq <= centro) {
				laMezcla[k] = actores[izq];
				k++;
				izq++;
			}
		}
		for (int j = inicio; j <= fin; j++) {
			actores[j] = laMezcla[j - inicio];
		}
	}

	public void eliminarActor(String nombre) {
		this.La.remove(nombre);
	}

	public void imprimirListaOrdenada() {
		String lo[] = this.ordenarActores();
		for (int i = 0; i < lo.length; i++) {
			System.out.println(lo[i]);
		}
	}

}
