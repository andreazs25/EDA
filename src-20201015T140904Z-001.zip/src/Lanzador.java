import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Lanzador {
	static Actor unActor = null;
	static Peli unaPeli;
	static String pNombre;
	static Graph2 miGrafo;
	static int botton;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		try {
			Stopwatch timer = new Stopwatch();
			

			Gestor.getGestor().CargarDatosFichero();
			 Gestor.getGestor().cargarActoresPorPeli();
			System.out.println(timer.elapsedTime());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		System.out
				.println("Se va a cargar el catalogo de peliculas y actores.");
		Gestor.getGestor().CargarDatosFichero();
		System.out
				.println("******************************************************************");
		System.out
				.println("XDXDXDXDXDXDXDXDXD**CATALOGUE DES FILMS**XDXDXDXDXDXDXDXDXDXD  ");
		System.out
				.println("*******************************************************************");
		System.out.println("- Opcion 1: Busqueda de un actor/actriz");
		System.out.println("- Opcion 2: Insercion de nuevo actor/actriz");
		System.out
				.println("- Opcion 3: Devolver las peliculas de un actor dado");
		System.out
				.println("- Opcion 4: Devolver los actores de una pelicula dada");
		System.out
				.println("- Opcion 5: Incrementar el dinero recaudado por una pelicula en un valor dado");
		System.out.println("- Opcion 6: Borrado de un@ actor/actriz");
		System.out.println("- Opcion 7: Guardar lista en fichero");
		System.out.println("- Opcion 8: Obtener una lista de actores ordenada");
		System.out.println("- Opcion 9: crear grafo. ");
		System.out.println("- Opcion 10: salir del menu. ");

		String cadena = sc.readLine();
		while (Integer.parseInt(cadena) < 10) {
			switch (cadena) {
			case "1":
				System.out.println("Introduce nombre del actor a buscar:");
				pNombre = sc.readLine();

				unActor = Gestor.getGestor().getListaA().buscarActor(pNombre);

				if (unActor == null) {
					System.out.println("El actor que buscas no esta.");
				} else {
					System.out.println(unActor.getNombre()
							+ " esta en la lista.");
				}

				break;
			case "2":
				System.out.println("Introduce Actor a insertar:");
				pNombre = sc.readLine();
				unActor = new Actor(pNombre);
				if (Gestor.getGestor().getListaA().buscarActor(pNombre) != null) {
					System.out.println("El actor ya esta introducido.");
				} else {
					System.out.println("Se va a insertar el actor " + pNombre);
					Gestor.getGestor().getListaA().anadir(unActor.getNombre());

				}
				break;

			case "3":
				System.out
						.println("Introduce un actor para mostrar su lista de peliculas:");
				pNombre = sc.readLine();
				unActor = Gestor.getGestor().getListaA().buscarActor(pNombre);
				if (unActor != null) {
					System.out.println("Actor " + unActor.getNombre());
					unActor.devolverListaDeActor();

				} else {

					System.out.println("El actor que buscas no esta.");
					System.out.println("" + pNombre);
				}

				break;
			case "4":
				System.out
						.println("introduce una pelicula para mostrar sus actores");
				pNombre = sc.readLine();
				unaPeli = Gestor.getGestor().getListaP().Devolver(pNombre);
				if (unaPeli == null) {
					System.out
							.println("La peli  que buscas no esta y no tiene actores.");
				} else {
					unaPeli.devolverListaDePeli();
				}
				break;
			case "5":
				System.out.println("introduce el nombre de la pelicula ");
				pNombre = sc.readLine();
				unaPeli = Gestor.getGestor().getListaP().Devolver(pNombre);
				System.out.println("ingrese dinero ");
				double dinero = Double.parseDouble(sc.readLine());
				unaPeli.incrementarReca(dinero);

				System.out.println("Se a recaudado\n"
						+ unaPeli.getRecaudacion());

				break;

			case "6":
				System.out.println("Introduce una actriz a borrar.");
				pNombre = sc.readLine();
				unActor = Gestor.getGestor().getListaA().buscarActor(pNombre);
				if (unActor != null) {
					Gestor.getGestor().getListaA()
							.eliminarActor(unActor.getNombre());
					// No me borra el actor
					System.out.println("Se borra actor.");
				} else
					System.out.println("no esta y no se borra.");
				{

				}
				break;

			case "7":
				System.out.println("guardar fichero.");

				Gestor.getGestor().guardarFichero();
				System.out
						.println("refresque en el eclipse y mire en fichero.");

				break;
			case "8":

				Gestor.getGestor().getListaA().imprimirListaOrdenada();
				System.out.println("se obtendra la lista de actores ordenada.");

				break;

			case "9":
				System.out.println("creamos grafo :)");
				miGrafo.print();
				
			
		case "10":
			System.out.println("El programa se ha cerrado, adios :)");
			botton = 10;
			System.exit(botton);
		}
			
			
			

			System.out
					.println("******************************************************************");
			System.out
					.println("XDXDXDXDXDXDXDXDXD**CATALOGUE DES FILMS**XDXDXDXDXDXDXDXDXDXD  ");
			System.out
					.println("*******************************************************************");
			System.out.println("- Opcion 1: Busqueda de un actor/actriz");
			System.out.println("- Opcion 2: Insercion de nuevo actor/actriz");
			System.out
					.println("- Opcion 3: Devolver las peliculas de un actor dado");
			System.out
					.println("- Opcion 4: Devolver los actores de una pelicula dada");
			System.out
					.println("- Opcion 5: Incrementar el dinero recaudado por una pelicula en un valor dado");
			System.out.println("- Opcion 6: Borrado de un@ actor/actriz");
			System.out.println("- Opcion 7: Guardar lista en fichero");
			System.out
					.println("- Opcion 8: Obtener una lista de actores ordenada");
			System.out.println("- Opcion 9: salir del menu. ");
			botton = Integer.parseInt(cadena);

			cadena = sc.readLine();

		}

	}
}