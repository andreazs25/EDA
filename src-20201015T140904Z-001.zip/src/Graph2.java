import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.Map.Entry;

public class Graph2 {
	TreeMap<String, Integer> th;
	String[] keys;
	ArrayList<Integer>[] adjList;

	public Graph2() {
		this.th = new TreeMap<String, Integer>();
		this.adjList = (ArrayList<Integer>[]) new ArrayList[th.size()];

	}

	public void crearGrafo() {
		/**
		 * Paso1:rellenamos th
		 * 
		 */
		int cont = 0;
		for (Entry<String, Actor> unActor : Gestor.getGestor().CatalogoA
				.getLista().entrySet()) {
			Actor a = unActor.getValue();
			th.put(a.getNombre(), cont);
			cont++;
			LisPeli listaP = a.getListaP();
			for (Entry<String, Peli> p : listaP.getLp().entrySet()) {
				Peli pe = p.getValue();
				if (!th.containsKey(pe.getTitulo())) {
					th.put(pe.getTitulo(), cont);
					cont++;
				}

			}
		}

		/**
		 * Paso2:rellenamos keys array que contiene todas las claves
		 * 
		 */
		keys = new String[th.size()];
		for (String k : th.keySet()) {
			keys[th.get(k)] = k;
			// System.out.println(k);

		}

		/**
		 * Paso3:llenar �adjList�
		 * 
		 */

		this.adjList = (ArrayList<Integer>[]) new ArrayList[th.size()];
		for (Entry<String, Actor> unActor : Gestor.getGestor().CatalogoA
				.getLista().entrySet()) {
			Actor a = unActor.getValue();

			LisPeli listaP = a.getListaP();
			for (Entry<String, Peli> p : listaP.getLp().entrySet()) {
				Peli pe = p.getValue();

				if (adjList[th.get(a.getNombre())] == null) {
					adjList[th.get(a.getNombre())] = new ArrayList<Integer>();
				}
				adjList[th.get(a.getNombre())].add(th.get(pe.getTitulo()));
				if (adjList[th.get(pe.getTitulo())] == null) {
					adjList[th.get(pe.getTitulo())] = new ArrayList<Integer>();
				}
				adjList[th.get(pe.getTitulo())].add(th.get(a.getNombre()));
			}

		}
	}

	public void print() {
		for (int i = 0; i < adjList.length; i++) {
			System.out.println("Element: " + i + " " + keys[i] + " --> ");

			for (int k : adjList[i])
				System.out.print(keys[k] + " ### ");

		}

	}

	public void obtenerAmigos(int c, Queue<Integer> porExaminar,
			HashMap<String, String> examinados) {

		for (int i = 0; i < this.adjList[c].size(); i++) {
			int peli = this.adjList[c].get(i);
			if (!examinados.containsKey(this.keys[peli])
					&& !porExaminar.contains(this.adjList[c].get(i))) {
				examinados.put(this.keys[peli], this.keys[c]);
				porExaminar.add(peli);
			}
			for (int j = 0; j < this.adjList[peli].size(); j++) {
				int act = this.adjList[peli].get(j);
				if (!examinados.containsKey(this.keys[act])
						&& !porExaminar.contains(this.adjList[peli].get(j))) {
					examinados.put(this.keys[act], this.keys[peli]);
					porExaminar.add(act);
				}
			}
			/*
			 * int act = this.adjList[c].get(i); if
			 * (!examinados.containsKey(this.keys[act]) &&
			 * !porExaminar.contains(this.adjList[c].get(i))) {
			 * examinados.put(this.keys[act], this.keys[c]);
			 * porExaminar.add(act);
			 * 
			 * }
			 */
		}

	}

	public boolean estanConectados(String a1, String a2) {

		Queue<Integer> porExaminar = new LinkedList<Integer>();
		HashMap<String, String> examinados = new HashMap<String, String>();
		porExaminar.add(th.get(a1));
		examinados.put(a1, a1);
		int fin = th.get(a2);
		boolean enc = false;
		if (a1 == a2) {
			enc = true;
		} else {
			while (!porExaminar.isEmpty() && !enc) {
				int c = porExaminar.remove();
				if (c == fin) {
					// examinados.put(a2, ant);
					enc = true;
				} else {
					// examinados.put(this.keys[c], ant);
					this.obtenerAmigos(c, porExaminar, examinados);

				}
			}
		}
		return enc;
	}

	public ArrayList<String> estanConectados2(String a1, String a2) {
		ArrayList<String> camino = new ArrayList<String>();
		Queue<Integer> porExaminar = new LinkedList<Integer>();
		HashMap<String, String> examinados = new HashMap<String, String>();
		porExaminar.add(th.get(a1));
		examinados.put(a1, a1);
		int fin = th.get(a2);
		boolean enc = false;
		if (a1 == a2) {
			camino.add(a1);
			return camino;
		} else {
			while (!porExaminar.isEmpty() && !enc) {
				int c = porExaminar.remove();
				if (c == fin) {
					enc = true;
				} else {
					this.obtenerAmigos(c, porExaminar, examinados);

				}
			}
			if (enc) {
				camino = this.devolverCamino(examinados, a2);
				return camino;
			} else {
				return camino;
			}
		}

	}

	public ArrayList<String> devolverCamino(HashMap<String, String> examinados,
			String a2) {

		String aux = a2;
		ArrayList<String> camino = new ArrayList<String>();
		String info = examinados.get(aux);
		while (aux != info) {
			camino.add(0, aux);
			aux = info;
			info = examinados.get(aux);
		}
		return camino;
	}

	public void imprimirCamino(ArrayList<String> camino) {
		String act;
		if (camino != null) {
			Iterator<String> itr = camino.iterator();
			while (itr.hasNext()) {
				act = itr.next();
				System.out.println(act);
			}
		} else {
			System.out.println("No estan conectados");
		}
	}

	public double gradoRelaciones() {
		ArrayList<String> la = new ArrayList<String>(
				Gestor.getGestor().CatalogoA.getLista().keySet());
		Random r = new Random();
		double sum = 0;
		int NUM_PRUEBAS = 300;
		for (int i = 0; i < NUM_PRUEBAS; i++) {
			String a1 = la.get(r.nextInt(la.size()));
			String a2 = la.get(r.nextInt(la.size()));
			int dist = this.estanConectados2(a1, a2).size();
			sum += dist;
		}
		return sum / NUM_PRUEBAS;
	}

	public ArrayList<Actor> losDeMasCentralidad(int n) {
		ArrayList<String> actores = new ArrayList<String>(
				Gestor.getGestor().CatalogoA.getLista().keySet());
		ArrayList<Actor> result = new ArrayList<Actor>();
		HashMap<String, Double> contCentralidad = new HashMap<String, Double>();
		Comparar vc = new Comparar(contCentralidad);
		TreeMap<String, Double> sorted_map = new TreeMap(vc);
		int NUM_PRUEBAS = 20000;
		Random rg = new Random();

		for (int i = 0; i < NUM_PRUEBAS; i++) {
			String a1 = actores.get(rg.nextInt(actores.size()));
			String a2 = actores.get(rg.nextInt(actores.size()));
			ArrayList<String> camino = estanConectados2(a1, a2);
			if (contCentralidad.containsKey(a1))
				contCentralidad.put(a1, contCentralidad.get(a1) + 1);
			else
				contCentralidad.put(a1, 1.0);
			for (String a : camino) {
				String r = a;
				if (r != a1) {
					if (contCentralidad.containsKey(r))
						contCentralidad.put(r, contCentralidad.get(r) + 1);
					else
						contCentralidad.put(r, 1.0);
				}
			}
		}

		sorted_map.putAll(contCentralidad);
		int cont = 0;
		System.out.println("tma�o " + sorted_map.size());
		for (Entry<String, Double> cent : sorted_map.entrySet()) {

			if (Gestor.getGestor().CatalogoA.getLista().containsKey(
					cent.getKey())) {
				if (cont < n) {
					Actor tem = Gestor.getGestor().CatalogoA.getLista().get(
							cent.getKey());
					System.out.println(tem.getNombre());

					tem.setCentralidad(cent.getValue());
					System.out.println(tem.getCentralidad());

					Gestor.getGestor().CatalogoA.getLista().put(cent.getKey(),
							tem);
					result.add(Gestor.getGestor().CatalogoA.getLista().get(
							cent.getKey()));
					cont++;

				} else {

					Actor tem = Gestor.getGestor().getListaA().getLista()
							.get(cent.getKey());

					tem.setCentralidad(cent.getValue());
					Gestor.getGestor().CatalogoA.getLista().put(cent.getKey(),
							tem);

				}
			}
		}
		return result;
	}
}
