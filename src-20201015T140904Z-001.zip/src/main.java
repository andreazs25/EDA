import java.io.IOException;
import java.util.TreeMap;

public class main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		// Gestor.getGestor().CargarDatosFichero();
		/**Actor a = new Actor("diana");
		Actor b = new Actor("sergio");
		Actor c = new Actor("ander");

		TreeMap<String, Actor> Actores = new TreeMap<String, Actor>();
		// TreeMap <String, Actor> ActoresOrdenados = new TreeMap<String,
		// Actor>();

		 * Actores.put(a.nombre, a); Actores.put(b.nombre, b);
		 * Actores.put(c.nombre, c);
		 * 
		 * Gestor.getGestor().CargarDatosFichero();
		 * //Gestor.getGestor().CatalogoA.anadirTreepMap(Actores, unActor);
		 * //Gestor.getGestor().CatalogoA.Ordenar(Actores); /** Peli a=null;
		 * for(int i=0; i<Gestor.getGestor().CatalogoP.longitud();i++){ a
		 * =Gestor.getGestor().CatalogoP.Devolver(a);
		 * System.out.println(""+a.titulo); }
		 **/
		/**
		 * System.out.println(""+Actores.size());
		 * Gestor.getGestor().CatalogoA.Ordenar(Actores);
		 * //System.out.println(""+Actores.size());
		 * Gestor.getGestor().CatalogoA.
		 * anadirEnMaE(Actores,Gestor.getGestor().CatalogoA );
		 * //System.out.println(""+Gestor.getGestor().CatalogoA.longitud());
		 **/

		Gestor.getGestor().CargarDatosFichero();
	}
}
